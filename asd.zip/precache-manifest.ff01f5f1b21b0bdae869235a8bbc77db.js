self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bbf7aa53e2fd6848986f57b0d8496a16",
    "url": "/index.html"
  },
  {
    "revision": "4b1afd54a71b49932e9a",
    "url": "/static/css/main.7758fdf2.chunk.css"
  },
  {
    "revision": "1f6dda971843b354710e",
    "url": "/static/js/2.8adc914f.chunk.js"
  },
  {
    "revision": "4b1afd54a71b49932e9a",
    "url": "/static/js/main.3956598d.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "83db33a2480491bad210210b4664e82e",
    "url": "/static/media/AloeVera.83db33a2.jpg"
  },
  {
    "revision": "8b3cd0a4181f3b076664f979661bc3d7",
    "url": "/static/media/Citrus.8b3cd0a4.jpg"
  },
  {
    "revision": "0286303ecc56c091bc1fa02ef9c9c7e4",
    "url": "/static/media/Curcumin.0286303e.jpg"
  },
  {
    "revision": "f316dee0997a38970f3f481ade7ea904",
    "url": "/static/media/Slide1.f316dee0.png"
  },
  {
    "revision": "ad1aaae3747db31f6234b7793616d5ea",
    "url": "/static/media/Slide2.ad1aaae3.png"
  },
  {
    "revision": "e06440bcf8ffa537d847cbb61f8fd7ae",
    "url": "/static/media/grouped.e06440bc.png"
  },
  {
    "revision": "0c48caf576986d8b3890188d5c467871",
    "url": "/static/media/logo.0c48caf5.png"
  },
  {
    "revision": "15393c5a215a67b0f4bbc4d4ed55f12c",
    "url": "/static/media/testimonials-3.15393c5a.jpg"
  }
]);