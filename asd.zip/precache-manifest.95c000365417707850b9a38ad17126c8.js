self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "197042c6a3a32f0bfc09066aa5f33ea4",
    "url": "/index.html"
  },
  {
    "revision": "5aeca2d9bb7b648458b4",
    "url": "/static/css/main.7758fdf2.chunk.css"
  },
  {
    "revision": "5251f32cf6b2045333f4",
    "url": "/static/js/2.53b14498.chunk.js"
  },
  {
    "revision": "5aeca2d9bb7b648458b4",
    "url": "/static/js/main.14e5e363.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "83db33a2480491bad210210b4664e82e",
    "url": "/static/media/AloeVera.83db33a2.jpg"
  },
  {
    "revision": "8b3cd0a4181f3b076664f979661bc3d7",
    "url": "/static/media/Citrus.8b3cd0a4.jpg"
  },
  {
    "revision": "0286303ecc56c091bc1fa02ef9c9c7e4",
    "url": "/static/media/Curcumin.0286303e.jpg"
  },
  {
    "revision": "ad1aaae3747db31f6234b7793616d5ea",
    "url": "/static/media/Slide2.ad1aaae3.png"
  },
  {
    "revision": "5cc070224fec3a0863b895388bf3f1e6",
    "url": "/static/media/active2.5cc07022.jpg"
  },
  {
    "revision": "9e3b801c0db1f05a81d79bed023af380",
    "url": "/static/media/biogloura_web3.9e3b801c.png"
  },
  {
    "revision": "e06440bcf8ffa537d847cbb61f8fd7ae",
    "url": "/static/media/grouped.e06440bc.png"
  },
  {
    "revision": "0c48caf576986d8b3890188d5c467871",
    "url": "/static/media/logo.0c48caf5.png"
  },
  {
    "revision": "15393c5a215a67b0f4bbc4d4ed55f12c",
    "url": "/static/media/testimonials-3.15393c5a.jpg"
  }
]);